**TimeLock by Matthew Di Ferrante**

Create the contract from your secure eth address that you want to control the contract from, send funds to it to the default function from anywhere, and they'll be locked up to a year (or whatever you set the lockTime variable to).
